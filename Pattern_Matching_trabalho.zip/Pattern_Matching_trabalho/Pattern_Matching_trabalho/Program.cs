﻿using System;

namespace Pattern_Matching_trabalho
{
    public class UsuarioBiblioteca
    {
        public string Nome { get; set; }
        public int QuantidadeEmprestimos { get; set; }
    }

    public class Aluno : UsuarioBiblioteca
    {
        public string Matricula { get; set; }
    }    public class Professor : UsuarioBiblioteca
    {
        public string Departamento { get; set; }
    }

    public class Visitante : UsuarioBiblioteca
    {
        public string Documento { get; set; }
    }

    class Program
    {
        public static string VerificarEmprestimo(object obj)
        {
            return obj switch
            {
                null => "Usuário inválido",

                Aluno { QuantidadeEmprestimos: < 3 }
                    => "Aluno pode realizar empréstimo",

                Aluno { QuantidadeEmprestimos: >= 3 }
                    => "Aluno atingiu o limite de empréstimos",
                                
                Professor { QuantidadeEmprestimos: < 5 }
                    => "Empréstimo autorizado para professor",

                Professor { QuantidadeEmprestimos: >= 5 }
                    => "Professor atingiu o limite de empréstimos",

                Visitante
                    => "Visitante não pode realizar empréstimos",

                _ => "Tipo de usuário não reconhecido"
            };
        }

        static void Main(string[] args)
        {
            Aluno aluno = new Aluno
            {
                Nome = "Pedro",
                Matricula = "2023001",
                QuantidadeEmprestimos = 2
            };

            Professor professor = new Professor
            {
                Nome = "Tiago",
                Departamento = "2023002",
                QuantidadeEmprestimos = 4
            };

            Visitante visitante = new Visitante
            {
                Nome = "João",
                Documento = "2023003",
                QuantidadeEmprestimos = 0
            };

            Console.WriteLine(VerificarEmprestimo(aluno));
            Console.WriteLine(VerificarEmprestimo(professor));
            Console.WriteLine(VerificarEmprestimo(visitante));
            Console.WriteLine(VerificarEmprestimo(null));
        }
    }
}