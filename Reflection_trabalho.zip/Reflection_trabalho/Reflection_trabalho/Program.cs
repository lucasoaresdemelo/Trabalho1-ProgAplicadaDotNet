﻿using System.Reflection;

class Program
{
    public static void ExibirDadosAberto(object objeto)
    {
        Type tipo = objeto.GetType();

        foreach (var propriedade in tipo.GetProperties())
        {
            object valor = propriedade.GetValue(objeto);

            Console.WriteLine($"{propriedade.Name}: {valor}");
        }
    }

    public static void ExibirDadosControlado(object objeto)
    {
        Type tipo = objeto.GetType();

        foreach (var propriedade in tipo.GetProperties())
        {
            var atributo = propriedade.GetCustomAttribute<ExibirAttribute>();

            if (atributo != null)
            {
                object valor = propriedade.GetValue(objeto);

                Console.WriteLine($"{propriedade.Name}: {valor}");
            }
        }
    }

    static void Main(string[] args)
    {
        Equipamento equipamento = new Equipamento
        {
            Id = 1,
            Nome = "Notebook",
            Fabricante = "Dell",
            NumeroSerie = "ABC123",
            Valor = 3500.00m,
            Localizacao = "Sala 01"
        };

        Console.WriteLine("REFLECTION ABERTA:");
        ExibirDadosAberto(equipamento);

        Console.WriteLine();

        Console.WriteLine("REFLECTION CONTROLADA:");
        ExibirDadosControlado(equipamento);
    }
}