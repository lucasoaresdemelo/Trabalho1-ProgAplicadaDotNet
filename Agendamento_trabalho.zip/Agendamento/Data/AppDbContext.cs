﻿using Agendamento.Models;
using Microsoft.EntityFrameworkCore;

namespace Agendamento.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }

        public DbSet<Medico> Medicos { get; set; }
        public DbSet<Paciente> Pacientes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Paciente>().HasData(
                new Paciente
                {
                    Id = 1,
                    Nome = "João Silva",
                    Cpf = "111.111.111-11",
                    Telefone = "(18) 99999-1111",
                    Endereco = "Rua A, 100",
                    DataNascimento = new DateTime(1990, 5, 10)
                },
                new Paciente
                {
                    Id = 2,
                    Nome = "Maria Souza",
                    Cpf = "222.222.222-22",
                    Telefone = "(18) 99999-2222",
                    Endereco = "Rua B, 200",
                    DataNascimento = new DateTime(1985, 8, 20)
                }
            );
        }
    }
}