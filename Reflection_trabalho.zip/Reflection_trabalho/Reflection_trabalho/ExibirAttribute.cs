﻿[AttributeUsage(AttributeTargets.Property)]
public class  ExibirAttribute : Attribute
{
}